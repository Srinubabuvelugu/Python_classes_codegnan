

class InsufficientBalanceError(Exception): 
    pass


class InvalidAccountError(Exception):
    pass


class AuthenticationError(Exception):
    pass


class InvalidAmountError(Exception):
    pass
